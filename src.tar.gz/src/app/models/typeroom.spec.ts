import { Typeroom } from './typeroom';

describe('Typeroom', () => {
  it('should create an instance', () => {
    expect(new Typeroom()).toBeTruthy();
  });
});
