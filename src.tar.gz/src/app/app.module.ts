import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ContactComponent } from './components/contact/contact.component';
import { TimeworkComponent } from './components/timework/timework.component';
import { FormsModule } from '@angular/forms';
import { TyperoomComponent } from './components/typeroom/typeroom.component';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [
    AppComponent,
    ContactComponent,
    TimeworkComponent,
    TyperoomComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path: '', component: TyperoomComponent},
      {path: 'typeroom', component: TyperoomComponent},
      {path: 'contact', component: ContactComponent},
      {path: 'timework', component: TimeworkComponent}
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
