import { Timework } from './timework';

describe('Timework', () => {
  it('should create an instance', () => {
    expect(new Timework()).toBeTruthy();
  });
});
